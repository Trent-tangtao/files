# This file holding some environment constant for sharing by other files
import torch

TORCH_VERSION = torch.__version__
