:orphan:

.. raw:: html

    <meta http-equiv="refresh" content="1; url=./compose.html" />
    <script>
      window.location.href = "./compose.html";
    </script>

This content is now at :ref:`combining_estimators`.
