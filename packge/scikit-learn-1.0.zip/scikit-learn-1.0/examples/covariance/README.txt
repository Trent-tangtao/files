.. _covariance_examples:

Covariance estimation
---------------------

Examples concerning the :mod:`sklearn.covariance` module.
